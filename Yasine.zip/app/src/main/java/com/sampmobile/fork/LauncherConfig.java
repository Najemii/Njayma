package com.sampmobile.fork;

/**
 * Central launcher configuration.
 *
 * Values are taken from the SpeedLife React-Native launcher
 * (SAMP-Launcher-RN: src/config/server.ts and .env) so both launchers
 * point to the same server and the same distribution file.
 */
public final class LauncherConfig {
    private LauncherConfig() {}

    // ---- Default server (auto-selected and auto-connected on entering the game)
    public static final String SERVER_NAME = "SpeedLife";
    public static final String SERVER_HOST = "45.138.16.241";
    public static final int SERVER_PORT = 8365;

    // ---- Distribution file (same URL as URL_DISTRIBUTION in the RN launcher's .env)
    public static final String DISTRIBUTION_URL =
            "https://raw.githubusercontent.com/Najemii/Njayma/main/distribution.json";
}
