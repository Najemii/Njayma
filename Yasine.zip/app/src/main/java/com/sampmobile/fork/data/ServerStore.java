package com.sampmobile.fork.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.sampmobile.fork.LauncherConfig;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Persists the favorite server list and the player nickname. */
public final class ServerStore {
    private static final String PREFS = "samp_launcher";
    private static final String KEY_SERVERS = "servers";
    private static final String KEY_NICKNAME = "nickname";
    private static final String KEY_SELECTED = "selected_server";

    private ServerStore() {}

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<ServerEntry> loadServers(Context ctx) {
        List<ServerEntry> out = new ArrayList<>();
        try {
            String raw = prefs(ctx).getString(KEY_SERVERS, "[]");
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new ServerEntry(
                        o.optString("name", ""),
                        o.optString("host", ""),
                        o.optInt("port", 7777)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void saveServers(Context ctx, List<ServerEntry> servers) {
        try {
            JSONArray arr = new JSONArray();
            for (ServerEntry s : servers) {
                JSONObject o = new JSONObject();
                o.put("name", s.name);
                o.put("host", s.host);
                o.put("port", s.port);
                arr.put(o);
            }
            prefs(ctx).edit().putString(KEY_SERVERS, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    /**
     * Makes sure the default server (LauncherConfig) is in the list and is the
     * selected one when nothing valid is selected. User-added servers are kept.
     */
    public static List<ServerEntry> ensureDefaultServer(Context ctx) {
        List<ServerEntry> list = loadServers(ctx);
        int idx = -1;
        for (int i = 0; i < list.size(); i++) {
            ServerEntry s = list.get(i);
            if (s.host.equals(LauncherConfig.SERVER_HOST) && s.port == LauncherConfig.SERVER_PORT) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            list.add(0, new ServerEntry(LauncherConfig.SERVER_NAME,
                    LauncherConfig.SERVER_HOST, LauncherConfig.SERVER_PORT));
            idx = 0;
            int sel = getSelected(ctx);
            // indexes shifted by the insert at 0
            if (sel >= 0) setSelected(ctx, sel + 1);
            saveServers(ctx, list);
        }
        int sel = getSelected(ctx);
        if (sel < 0 || sel >= list.size()) setSelected(ctx, idx);
        return list;
    }

    public static String getNickname(Context ctx) {
        return prefs(ctx).getString(KEY_NICKNAME, "Player");
    }

    public static void setNickname(Context ctx, String nickname) {
        prefs(ctx).edit().putString(KEY_NICKNAME, nickname).apply();
    }

    public static int getSelected(Context ctx) {
        return prefs(ctx).getInt(KEY_SELECTED, -1);
    }

    public static void setSelected(Context ctx, int index) {
        prefs(ctx).edit().putInt(KEY_SELECTED, index).apply();
    }
}
