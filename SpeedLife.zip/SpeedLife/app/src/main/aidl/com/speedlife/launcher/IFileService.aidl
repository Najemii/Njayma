package com.speedlife.launcher;

interface IFileService {
    void destroy() = 16777114;
    String copyTree(String src, String dst) = 1;
}
