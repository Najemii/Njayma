package com.speedlife.app

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val StatusGreen = Color(0xFF2ECC71)
val StatusRed = Color(0xFFE74C3C)
val StatusYellow = Color(0xFFF1C40F)

/** Small round dot: green (pulsing) = connected to the database, red = not connected, yellow = checking. */
@Composable
fun StatusDot(online: Boolean?, modifier: Modifier = Modifier) {
    val color = when (online) {
        true -> StatusGreen
        false -> StatusRed
        null -> StatusYellow
    }
    val t = rememberInfiniteTransition(label = "dot")
    val pulse by t.animateFloat(
        initialValue = 1f,
        targetValue = 2.4f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    val pulseAlpha by t.animateFloat(
        initialValue = 0.55f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "pulseAlpha"
    )
    Box(modifier.size(20.dp), contentAlignment = Alignment.Center) {
        if (online == true) {
            Box(
                Modifier
                    .size(10.dp)
                    .graphicsLayer {
                        scaleX = pulse
                        scaleY = pulse
                        alpha = pulseAlpha
                    }
                    .background(color, CircleShape)
            )
        }
        Box(Modifier.size(10.dp).background(color, CircleShape))
    }
}

/** Dot + text (+ the reason under it when offline). */
@Composable
fun StatusPill(online: Boolean?, detail: String?, modifier: Modifier = Modifier) {
    val color = when (online) {
        true -> StatusGreen
        false -> StatusRed
        null -> StatusYellow
    }
    val label = when (online) {
        true -> "Connected to database"
        false -> "Not connected to database"
        null -> "Checking connection..."
    }
    Column(modifier) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(Color(0x22FFFFFF))
                .padding(start = 8.dp, end = 14.dp, top = 5.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusDot(online)
            Spacer(Modifier.width(6.dp))
            Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        if (online == false && !detail.isNullOrBlank()) {
            Text(
                detail,
                color = Color(0xFFB8B8C0),
                fontSize = 11.sp, lineHeight = 14.sp,
                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
            )
        }
    }
}

/** "SpeedLife" with a light sweeping through the letters, a breathing red glow and a slight float. */
@Composable
fun SpeedLifeTitle(modifier: Modifier = Modifier, fontSize: TextUnit = 24.sp) {
    val t = rememberInfiniteTransition(label = "title")
    val shift by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart),
        label = "shift"
    )
    val glow by t.animateFloat(
        initialValue = 6f,
        targetValue = 26f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    val floatY by t.animateFloat(
        initialValue = -2f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float"
    )
    val dens = LocalDensity.current
    val band = with(dens) { fontSize.toPx() * 5f }
    val x = shift * band
    Text(
        text = "SpeedLife",
        modifier = modifier.graphicsLayer { translationY = floatY * density },
        style = TextStyle(
            brush = Brush.linearGradient(
                colors = listOf(SpeedRed, Color.White, SpeedRed),
                start = Offset(x, 0f),
                end = Offset(x + band, 0f),
                tileMode = TileMode.Mirror
            ),
            fontSize = fontSize,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            letterSpacing = 2.sp,
            shadow = Shadow(color = SpeedRed.copy(alpha = 0.85f), offset = Offset.Zero, blurRadius = glow)
        )
    )
}

/** Dark background with two soft glows (red and gold) that slowly drift. */
@Composable
fun AnimatedBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "bg")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bgp"
    )
    Canvas(modifier) {
        drawRect(SpeedBg)
        val w = size.width
        val h = size.height
        drawRect(
            Brush.radialGradient(
                colors = listOf(SpeedRed.copy(alpha = 0.24f), Color.Transparent),
                center = Offset(w * (0.15f + 0.7f * p), h * 0.12f),
                radius = w * 0.95f
            )
        )
        drawRect(
            Brush.radialGradient(
                colors = listOf(SpeedGold.copy(alpha = 0.09f), Color.Transparent),
                center = Offset(w * (0.85f - 0.7f * p), h * 0.92f),
                radius = w * 0.85f
            )
        )
    }
}
