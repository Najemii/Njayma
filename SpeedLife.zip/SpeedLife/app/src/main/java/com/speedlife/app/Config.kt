package com.speedlife.app

object Config {
    // Full address of api.php after you upload it to your web hosting.
    // Uploaded to: htdocs/api.php
    const val API_URL = "https://speed.freepage.cc/api.php"

    // Car picture shown in the shop (by GTA SA model id). If the picture
    // does not load, the app shows a plain dark box instead.
    fun carImageUrl(modelId: Int): String =
        "https://assets.open.mp/assets/images/vehiclePictures/Vehicle_$modelId.jpg"
}
