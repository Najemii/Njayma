package com.speedlife.app

object Config {
    // ---- MySQL (direct connection from the app) ----
    const val DB_URL = "jdbc:mysql://82.39.186.143:3306/s25_speedlife" +
        "?useSSL=false&connectTimeout=10000&socketTimeout=25000&characterEncoding=utf8" +
        "&tinyInt1isBit=false&zeroDateTimeBehavior=convertToNull"
    const val DB_USER = "u25_qqIhit5WTD"
    const val DB_PASS = "n0jEjBukulN4U7goab3+q=t3"

    // ---- SA-MP server (used to check that the buyer is NOT online in game) ----
    const val SAMP_HOST = "82.39.186.143"
    const val SAMP_PORT = 7013
    // true = purchase refused while the player is connected in game
    // (the gamemode would overwrite the money / cars changed by the app)
    const val REQUIRE_OFFLINE_TO_BUY = true

    // Players with adminlevel >= this value can use Upload in Announce and Shop
    const val ADMIN_MIN_LEVEL = 1

    // Where a bought car is placed in the database (same as the gamemode dealership)
    const val CAR_SPAWN_X = 562.3970
    const val CAR_SPAWN_Y = -1283.8485
    const val CAR_SPAWN_Z = 17.0007
    const val CAR_SPAWN_A = 0.0

    // Car picture shown in the shop (by GTA SA model id). If it does not load,
    // the app shows a plain dark box instead.
    fun carImageUrl(modelId: Int): String =
        "https://assets.open.mp/assets/images/vehiclePictures/Vehicle_$modelId.jpg"
}
