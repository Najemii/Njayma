package com.speedlife.launcher

object Config {
    /** Password of the data zip chosen by the player */
    const val DATA_PASSWORD = "166"

    /**
     * The zip root is extracted into: Android/data/<package>/<TARGET_SUBDIR>
     * Empty = directly into Android/data/<package>/  (zip contains: files, mods, configs)
     */
    const val TARGET_SUBDIR = ""

    /** Words used to filter the app list (the player can show all apps) */
    val NAME_HINTS = listOf("samp", "sa-mp", "gta", "launcher", "mobile")

    fun targetRelPath(pkg: String): String =
        "Android/data/$pkg" + if (TARGET_SUBDIR.isEmpty()) "" else "/$TARGET_SUBDIR"
}
