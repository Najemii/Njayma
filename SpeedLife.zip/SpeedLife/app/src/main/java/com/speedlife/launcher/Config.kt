package com.speedlife.launcher

object Config {
    /** كلمة سر ملف الـ zip الذي يختاره اللاعب */
    const val DATA_PASSWORD = "166"

    /** مجلد الداتا داخل اللانشر: Android/data/<package>/<TARGET_SUBDIR> */
    const val TARGET_SUBDIR = "files"

    /** كلمات تُستخدم لتصفية قائمة التطبيقات (يمكن إظهار الكل من الزر) */
    val NAME_HINTS = listOf("samp", "sa-mp", "gta", "launcher", "mobile")
}
