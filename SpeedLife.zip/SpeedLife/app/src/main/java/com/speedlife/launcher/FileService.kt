package com.speedlife.launcher

import java.io.File
import java.io.FileOutputStream

/** تعمل بصلاحيات shell عبر Shizuku، وتنسخ الملفات داخل Android/data الخاص بتطبيقات أخرى */
class FileService : IFileService.Stub() {

    override fun destroy() {
        System.exit(0)
    }

    override fun copyTree(src: String, dst: String): String {
        return try {
            copy(File(src), File(dst))
            ""
        } catch (e: Throwable) {
            e.toString()
        }
    }

    private fun copy(s: File, d: File) {
        if (s.isDirectory) {
            d.mkdirs()
            s.listFiles()?.forEach { copy(it, File(d, it.name)) }
        } else {
            d.parentFile?.mkdirs()
            s.inputStream().use { i -> FileOutputStream(d).use { i.copyTo(it) } }
        }
    }
}
