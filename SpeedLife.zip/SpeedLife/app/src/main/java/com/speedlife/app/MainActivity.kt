package com.speedlife.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

val SpeedRed = Color(0xFFE10600)
val SpeedGold = Color(0xFFFFC83D)
val SpeedBg = Color(0xFF0B0B0D)
val SpeedSurface = Color(0xFF17171B)

private val SpeedColors = darkColorScheme(
    primary = SpeedRed,
    onPrimary = Color.White,
    secondary = Color(0xFFD9D9DE),
    background = SpeedBg,
    onBackground = Color.White,
    surface = SpeedSurface,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF24242A),
    onSurfaceVariant = Color(0xFFB8B8C0),
    error = Color(0xFFFF6B6B)
)

fun formatMoney(value: Long): String =
    "$" + NumberFormat.getIntegerInstance(Locale.US).format(value)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots / screen recording so announcement pictures cannot be saved.
        // Delete the next line if you want to allow screenshots.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        setContent {
            MaterialTheme(colorScheme = SpeedColors) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val vm: AppViewModel = viewModel()
                    if (vm.token == null) LoginScreen(vm) else MainShell(vm)
                }
            }
        }
    }
}

enum class Screen { ANNOUNCE, SHOP, PROFILE }

@Composable
fun MainShell(vm: AppViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.ANNOUNCE) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.refreshProfile() }
    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            snackbar.showSnackbar(m)
            vm.message = null
        }
    }

    BackHandler(enabled = drawerState.isOpen || screen == Screen.PROFILE) {
        if (drawerState.isOpen) scope.launch { drawerState.close() } else screen = Screen.ANNOUNCE
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "SpeedLife",
                    style = MaterialTheme.typography.headlineSmall,
                    color = SpeedRed,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Announce") },
                    selected = screen == Screen.ANNOUNCE,
                    onClick = {
                        screen = Screen.ANNOUNCE
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Shop") },
                    selected = screen == Screen.SHOP,
                    onClick = {
                        screen = Screen.SHOP
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopBar(
                    cash = vm.profile?.cash,
                    onMenu = { scope.launch { drawerState.open() } },
                    onProfile = { screen = Screen.PROFILE }
                )
            },
            snackbarHost = { SnackbarHost(snackbar) },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.ANNOUNCE -> AnnounceScreen(vm)
                    Screen.SHOP -> ShopScreen(vm)
                    Screen.PROFILE -> ProfileScreen(vm)
                }
            }
        }
    }
}

@Composable
fun TopBar(cash: Long?, onMenu: () -> Unit, onProfile: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onMenu) {
                Text("☰", fontSize = 26.sp, color = Color.White)
            }
            Text(
                text = if (cash != null) formatMoney(cash) else "...",
                style = MaterialTheme.typography.titleLarge,
                color = SpeedGold,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = onProfile,
                colors = ButtonDefaults.buttonColors(containerColor = SpeedRed)
            ) {
                Text("Profile")
            }
        }
    }
}
