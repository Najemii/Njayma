package com.speedlife.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun ShopScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.loadShop() }
    var showUpload by remember { mutableStateOf(false) }
    var confirmItem by remember { mutableStateOf<ShopItem?>(null) }
    val isAdmin = vm.profile?.isAdmin == true

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Shop",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { vm.loadShop() }) { Text("Refresh") }
                if (isAdmin) {
                    Spacer(Modifier.padding(start = 4.dp))
                    Button(
                        onClick = { showUpload = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SpeedRed)
                    ) { Text("Upload") }
                }
            }
        }
        if (vm.shopItems.isEmpty() && !vm.busy) {
            item { Text("The shop is empty right now.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(vm.shopItems, key = { it.id }) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    AsyncImage(
                        model = Config.carImageUrl(item.modelId),
                        contentDescription = null,
                        placeholder = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                        error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                    )
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                VehicleNames.nameOf(item.modelId),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(formatMoney(item.price), color = SpeedGold)
                            Text(
                                "In stock: ${item.quantity}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            enabled = !vm.busy && item.quantity > 0,
                            onClick = { confirmItem = item },
                            colors = ButtonDefaults.buttonColors(containerColor = SpeedRed)
                        ) { Text("Buy") }
                    }
                }
            }
        }
    }

    val toBuy = confirmItem
    if (toBuy != null) {
        AlertDialog(
            onDismissRequest = { confirmItem = null },
            title = { Text("Confirm purchase") },
            text = {
                Text(
                    "Buy ${VehicleNames.nameOf(toBuy.modelId)} for ${formatMoney(toBuy.price)}?\n\n" +
                        "The money is taken from your in-game cash and the car is added to your account " +
                        "(use /garage in the game). You must be offline in the game to buy."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.buy(toBuy.id)
                    confirmItem = null
                }) { Text("Buy") }
            },
            dismissButton = {
                TextButton(onClick = { confirmItem = null }) { Text("Cancel") }
            }
        )
    }

    if (showUpload) {
        var carId by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        val model = carId.toIntOrNull()
        val priceVal = price.toLongOrNull()
        val qtyVal = qty.toIntOrNull()
        val valid = model != null && VehicleNames.isValid(model) &&
            priceVal != null && priceVal > 0 && qtyVal != null && qtyVal > 0

        AlertDialog(
            onDismissRequest = { showUpload = false },
            title = { Text("Add a car to the shop") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = carId,
                        onValueChange = { carId = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("Car ID (400 - 611)") },
                        supportingText = {
                            if (model != null) {
                                Text(if (VehicleNames.isValid(model)) VehicleNames.nameOf(model) else "Invalid car ID")
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = price,
                        onValueChange = { price = it.filter { c -> c.isDigit() }.take(10) },
                        label = { Text("Price") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = qty,
                        onValueChange = { qty = it.filter { c -> c.isDigit() }.take(4) },
                        label = { Text("Quantity") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !vm.busy && valid,
                    onClick = {
                        vm.createShopItem(model!!, priceVal!!, qtyVal!!) { showUpload = false }
                    }
                ) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showUpload = false }) { Text("Cancel") }
            }
        )
    }
}
