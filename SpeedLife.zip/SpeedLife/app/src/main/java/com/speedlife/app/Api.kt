package com.speedlife.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class Profile(
    val uid: Int,
    val username: String,
    val cash: Long,
    val bank: Long,
    val level: Int,
    val hours: Int,
    val isAdmin: Boolean,
    val adminLevel: Int,
    val faction: String,
    val factionRank: String,
    val gang: String,
    val gangRank: String,
    val job: String,
    val secondJob: String,
    val phone: Int,
    val vehicles: Int,
    val registered: String,
    val lastLogin: String
)

data class Announcement(
    val id: Int,
    val author: String,
    val imageUrl: String,
    val message: String,
    val createdAt: String
)

data class ShopItem(
    val id: Int,
    val modelId: Int,
    val price: Long,
    val quantity: Int
)

class ApiResult(
    val ok: Boolean,
    val error: String,
    val authFailed: Boolean,
    val json: JSONObject
)

fun JSONObject.toProfile() = Profile(
    uid = optInt("uid"),
    username = optString("username"),
    cash = optLong("cash"),
    bank = optLong("bank"),
    level = optInt("level"),
    hours = optInt("hours"),
    isAdmin = optBoolean("is_admin"),
    adminLevel = optInt("admin_level"),
    faction = optString("faction"),
    factionRank = optString("faction_rank"),
    gang = optString("gang"),
    gangRank = optString("gang_rank"),
    job = optString("job"),
    secondJob = optString("second_job"),
    phone = optInt("phone"),
    vehicles = optInt("vehicles"),
    registered = optString("registered"),
    lastLogin = optString("last_login")
)

fun JSONObject.toAnnouncement() = Announcement(
    id = optInt("id"),
    author = optString("author"),
    imageUrl = optString("image_url"),
    message = optString("message"),
    createdAt = optString("created_at")
)

fun JSONObject.toShopItem() = ShopItem(
    id = optInt("id"),
    modelId = optInt("model_id"),
    price = optLong("price"),
    quantity = optInt("quantity")
)

object Api {
    // Same call shape as before, but the work is done by Backend (direct MySQL).
    suspend fun call(
        action: String,
        token: String?,
        build: JSONObject.() -> Unit = {}
    ): ApiResult = withContext(Dispatchers.IO) {
        val input = JSONObject()
        input.build()
        try {
            val json = Backend.handle(action, token, input)
            ApiResult(
                json.optBoolean("ok"),
                json.optString("error", "Unknown error"),
                json.optBoolean("auth_failed"),
                json
            )
        } catch (e: Throwable) {
            ApiResult(false, "Database connection failed: " + (e.message ?: e.javaClass.simpleName), false, JSONObject())
        }
    }
}
