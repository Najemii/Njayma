package com.speedlife.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Profile(
    val uid: Int,
    val username: String,
    val cash: Long,
    val bank: Long,
    val level: Int,
    val hours: Int,
    val isAdmin: Boolean,
    val adminLevel: Int,
    val faction: String,
    val factionRank: String,
    val gang: String,
    val gangRank: String,
    val job: String,
    val secondJob: String,
    val phone: Int,
    val vehicles: Int,
    val registered: String,
    val lastLogin: String
)

data class Announcement(
    val id: Int,
    val author: String,
    val imageUrl: String,
    val message: String,
    val createdAt: String
)

data class ShopItem(
    val id: Int,
    val modelId: Int,
    val price: Long,
    val quantity: Int
)

class ApiResult(
    val ok: Boolean,
    val error: String,
    val authFailed: Boolean,
    val json: JSONObject
)

fun JSONObject.toProfile() = Profile(
    uid = optInt("uid"),
    username = optString("username"),
    cash = optLong("cash"),
    bank = optLong("bank"),
    level = optInt("level"),
    hours = optInt("hours"),
    isAdmin = optBoolean("is_admin"),
    adminLevel = optInt("admin_level"),
    faction = optString("faction"),
    factionRank = optString("faction_rank"),
    gang = optString("gang"),
    gangRank = optString("gang_rank"),
    job = optString("job"),
    secondJob = optString("second_job"),
    phone = optInt("phone"),
    vehicles = optInt("vehicles"),
    registered = optString("registered"),
    lastLogin = optString("last_login")
)

fun JSONObject.toAnnouncement() = Announcement(
    id = optInt("id"),
    author = optString("author"),
    imageUrl = optString("image_url"),
    message = optString("message"),
    createdAt = optString("created_at")
)

fun JSONObject.toShopItem() = ShopItem(
    id = optInt("id"),
    modelId = optInt("model_id"),
    price = optLong("price"),
    quantity = optInt("quantity")
)

object Api {
    suspend fun call(
        action: String,
        token: String?,
        build: JSONObject.() -> Unit = {}
    ): ApiResult = withContext(Dispatchers.IO) {
        val body = JSONObject()
        body.put("action", action)
        if (token != null) body.put("token", token)
        body.build()

        var conn: HttpURLConnection? = null
        try {
            conn = URL(Config.API_URL).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                null
            }
            if (json == null) {
                ApiResult(false, "Server error ($code). Check API_URL.", false, JSONObject())
            } else {
                ApiResult(
                    json.optBoolean("ok"),
                    json.optString("error", "Unknown error"),
                    json.optBoolean("auth_failed"),
                    json
                )
            }
        } catch (e: Exception) {
            ApiResult(false, "Connection failed. Check your internet.", false, JSONObject())
        } finally {
            conn?.disconnect()
        }
    }
}
