package com.speedlife.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun ProfileScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.refreshProfile() }
    val p = vm.profile

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = p?.username ?: "Profile",
                style = MaterialTheme.typography.headlineMedium,
                color = SpeedGold
            )
        }
        if (p == null) {
            item { Text("Loading...", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoRow("Cash", formatMoney(p.cash))
                        InfoRow("Bank", formatMoney(p.bank))
                        InfoRow("Level", p.level.toString())
                        InfoRow("Hours played", p.hours.toString())
                        InfoRow("Phone", if (p.phone > 0) p.phone.toString() else "None")
                        InfoRow("Vehicles", p.vehicles.toString())
                    }
                }
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoRow("Faction", p.faction)
                        if (p.factionRank.isNotEmpty()) InfoRow("Faction rank", p.factionRank)
                        InfoRow("Gang", p.gang)
                        if (p.gangRank.isNotEmpty()) InfoRow("Gang rank", p.gangRank)
                        InfoRow("Job", p.job)
                        InfoRow("Second job", p.secondJob)
                        if (p.isAdmin) InfoRow("Admin level", p.adminLevel.toString())
                    }
                }
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoRow("Registered", p.registered.take(10))
                        InfoRow("Last login", p.lastLogin.take(16))
                    }
                }
            }
        }
        item {
            Button(
                onClick = { vm.logout() },
                colors = ButtonDefaults.buttonColors(containerColor = SpeedRed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Log out")
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, textAlign = TextAlign.End, modifier = Modifier.padding(start = 16.dp))
    }
}
