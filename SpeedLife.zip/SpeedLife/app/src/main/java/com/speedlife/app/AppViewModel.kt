package com.speedlife.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("speedlife", Context.MODE_PRIVATE)

    var token by mutableStateOf<String?>(prefs.getString("token", null))
        private set
    var profile by mutableStateOf<Profile?>(null)
        private set
    var announcements by mutableStateOf<List<Announcement>>(emptyList())
        private set
    var shopItems by mutableStateOf<List<ShopItem>>(emptyList())
        private set

    var busy by mutableStateOf(false)
        private set
    var loginError by mutableStateOf<String?>(null)
        private set

    // One-line message shown at the bottom of the screen (snackbar)
    var message by mutableStateOf<String?>(null)

    private suspend fun authed(action: String, build: org.json.JSONObject.() -> Unit = {}): ApiResult? {
        val t = token ?: return null
        val r = Api.call(action, t, build)
        if (r.authFailed) {
            logout()
            loginError = "Session expired. Please log in again."
            return null
        }
        return r
    }

    fun login(username: String, password: String) {
        if (username.isBlank() || password.isEmpty()) {
            loginError = "Enter your in-game username and password."
            return
        }
        viewModelScope.launch {
            busy = true
            loginError = null
            val r = Api.call("login", null) {
                put("username", username.trim())
                put("password", password)
            }
            busy = false
            if (r.ok) {
                val t = r.json.optString("token")
                prefs.edit().putString("token", t).apply()
                profile = r.json.optJSONObject("profile")?.toProfile()
                token = t
            } else {
                loginError = r.error
            }
        }
    }

    fun logout() {
        prefs.edit().remove("token").apply()
        token = null
        profile = null
        announcements = emptyList()
        shopItems = emptyList()
    }

    fun refreshProfile() {
        viewModelScope.launch {
            val r = authed("me") ?: return@launch
            if (r.ok) profile = r.json.optJSONObject("profile")?.toProfile()
            else message = r.error
        }
    }

    fun loadAnnouncements() {
        viewModelScope.launch {
            busy = true
            val r = authed("announce_list")
            busy = false
            if (r == null) return@launch
            if (r.ok) {
                val arr = r.json.optJSONArray("items")
                val list = ArrayList<Announcement>()
                if (arr != null) for (i in 0 until arr.length()) list.add(arr.getJSONObject(i).toAnnouncement())
                announcements = list
            } else {
                message = r.error
            }
        }
    }

    fun createAnnouncement(imageUrl: String, text: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            busy = true
            val r = authed("announce_create") {
                put("image_url", imageUrl.trim())
                put("message", text.trim())
            }
            busy = false
            if (r == null) return@launch
            if (r.ok) {
                onSuccess()
                message = "Announcement published."
                loadAnnouncements()
            } else {
                message = r.error
            }
        }
    }

    fun loadShop() {
        viewModelScope.launch {
            busy = true
            val r = authed("shop_list")
            busy = false
            if (r == null) return@launch
            if (r.ok) {
                val arr = r.json.optJSONArray("items")
                val list = ArrayList<ShopItem>()
                if (arr != null) for (i in 0 until arr.length()) list.add(arr.getJSONObject(i).toShopItem())
                shopItems = list
            } else {
                message = r.error
            }
        }
    }

    fun createShopItem(modelId: Int, price: Long, quantity: Int, onSuccess: () -> Unit) {
        viewModelScope.launch {
            busy = true
            val r = authed("shop_create") {
                put("model_id", modelId)
                put("price", price)
                put("quantity", quantity)
            }
            busy = false
            if (r == null) return@launch
            if (r.ok) {
                onSuccess()
                message = "Car added to the shop."
                loadShop()
            } else {
                message = r.error
            }
        }
    }

    fun buy(itemId: Int) {
        viewModelScope.launch {
            busy = true
            val r = authed("shop_buy") { put("item_id", itemId) }
            busy = false
            if (r == null) return@launch
            message = if (r.ok) r.json.optString("message", "Purchased!") else r.error
            if (r.ok) refreshProfile()
            loadShop()
        }
    }
}
