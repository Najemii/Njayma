package com.speedlife.launcher

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.net.Uri
import android.os.Environment
import android.os.IBinder
import androidx.documentfile.provider.DocumentFile
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * ينسخ الداتا إلى اللانشر بطريقة الدمج:
 * الملفات الجديدة تُضاف، والموجودة بنفس الاسم تُستبدل، وأي ملف آخر في اللانشر يبقى كما هو.
 * progress(done, total, text): total = -1 يعني تقدم غير محدد.
 */
interface Applier {
    fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit)
}

/** أندرويد 10: وصول مباشر */
class LegacyApplier : Applier {
    override fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit) {
        val root = File(Environment.getExternalStorageDirectory(), Config.targetRelPath(pkg))
        val n = src.entries.size
        src.entries.forEachIndexed { i, rel ->
            val f = File(root, cleanRel(rel).joinToString("/"))
            f.parentFile?.mkdirs()
            src.open(rel).use { inp -> FileOutputStream(f).use { inp.copyTo(it) } }
            progress(i + 1, n, "Copying ${i + 1}/$n")
        }
    }
}

/** أندرويد 11-12: اختيار المجلد عبر SAF */
class SafApplier(private val ctx: Context, private val tree: Uri) : Applier {

    private fun child(dir: DocumentFile, name: String): DocumentFile =
        dir.findFile(name) ?: dir.createDirectory(name) ?: throw IOException("Could not create folder $name")

    override fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit) {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: throw IOException("Invalid folder")
        if (!root.canWrite()) throw IOException("No write permission on the selected folder")

        // the player picked Android/data/<pkg> or Android/data
        val pkgDir = if (root.name == pkg) root else child(root, pkg)
        val base = if (Config.TARGET_SUBDIR.isEmpty()) pkgDir else child(pkgDir, Config.TARGET_SUBDIR)

        val dirs = HashMap<String, DocumentFile>()
        fun dirFor(parts: List<String>): DocumentFile {
            var cur = base
            var key = ""
            for (p in parts) {
                key = if (key.isEmpty()) p else "$key/$p"
                val parent = cur
                cur = dirs.getOrPut(key) { child(parent, p) }
            }
            return cur
        }

        val n = src.entries.size
        src.entries.forEachIndexed { i, rel ->
            val parts = cleanRel(rel)
            val name = parts.last()
            val dir = dirFor(parts.dropLast(1))
            dir.findFile(name)?.delete()
            val doc = dir.createFile("application/octet-stream", name)
                ?: throw IOException("Could not create file $rel")
            val out = ctx.contentResolver.openOutputStream(doc.uri, "wt")
                ?: throw IOException("Could not write $rel")
            out.use { o -> src.open(rel).use { it.copyTo(o) } }
            progress(i + 1, n, "Copying ${i + 1}/$n")
        }
    }
}

/** All versions (mainly Android 13-15): through Shizuku */
class ShizukuApplier(private val ctx: Context) : Applier {

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** Runs a shell command with Shizuku (adb/root) privileges */
    private fun shell(cmd: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        return Pair(code, out.trim())
    }

    override fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit) {
        val target = File(Environment.getExternalStorageDirectory(), Config.targetRelPath(pkg)).absolutePath
        val stage = File(ctx.getExternalFilesDir(null) ?: throw IOException("No external storage"), "stage")

        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, FileService::class.java.name))
            .processNameSuffix("fs")
            .daemon(false)
            .version(1)
        var conn: ServiceConnection? = null
        try {
            // 1) Check the connection FIRST (fail fast, before preparing big files)
            progress(0, -1, "Connecting to Shizuku...")
            val shellOk = try { shell("id -u").first == 0 } catch (e: Throwable) { false }
            var service: IFileService? = null
            if (!shellOk) {
                val latch = CountDownLatch(1)
                var svc: IFileService? = null
                val c = object : ServiceConnection {
                    override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                        if (binder != null && binder.pingBinder()) svc = IFileService.Stub.asInterface(binder)
                        latch.countDown()
                    }
                    override fun onServiceDisconnected(name: ComponentName?) {}
                }
                conn = c
                Shizuku.bindUserService(args, c)
                latch.await(15, TimeUnit.SECONDS)
                service = svc
                if (service == null) {
                    throw IOException("Could not talk to Shizuku. Open Shizuku, make sure it is running and SpeedLife is authorized")
                }
            }

            // 2) Prepare the files in a temporary folder that the shell can read
            stage.deleteRecursively()
            stage.mkdirs()
            val n = src.entries.size
            src.entries.forEachIndexed { i, rel ->
                val f = File(stage, cleanRel(rel).joinToString("/"))
                f.parentFile?.mkdirs()
                src.open(rel).use { inp -> FileOutputStream(f).use { inp.copyTo(it) } }
                progress(i + 1, n, "Preparing ${i + 1}/$n")
            }

            // 3) Merge into the launcher data folder
            progress(0, -1, "Copying to launcher...")
            if (shellOk) {
                val s = q(stage.absolutePath)
                val d = q(target)
                val r = shell("mkdir -p $d && (cp -rf $s/. $d/ || (cd $s && cp -rf . $d/))")
                if (r.first != 0) throw IOException("Copy failed: ${r.second}")
            } else {
                val err = service!!.copyTree(stage.absolutePath, target)
                if (err.isNotEmpty()) throw IOException(err)
            }
        } finally {
            try { conn?.let { Shizuku.unbindUserService(args, it, true) } } catch (_: Throwable) {}
            stage.deleteRecursively()
        }
    }
}
