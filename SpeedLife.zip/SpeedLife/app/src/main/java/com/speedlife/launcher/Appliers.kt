package com.speedlife.launcher

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.net.Uri
import android.os.Environment
import android.os.IBinder
import androidx.documentfile.provider.DocumentFile
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * ينسخ الداتا إلى اللانشر بطريقة الدمج:
 * الملفات الجديدة تُضاف، والموجودة بنفس الاسم تُستبدل، وأي ملف آخر في اللانشر يبقى كما هو.
 * progress(done, total, text): total = -1 يعني تقدم غير محدد.
 */
interface Applier {
    fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit)
}

/** أندرويد 10: وصول مباشر */
class LegacyApplier : Applier {
    override fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit) {
        val root = File(Environment.getExternalStorageDirectory(), "Android/data/$pkg/${Config.TARGET_SUBDIR}")
        val n = src.entries.size
        src.entries.forEachIndexed { i, rel ->
            val f = File(root, cleanRel(rel).joinToString("/"))
            f.parentFile?.mkdirs()
            src.open(rel).use { inp -> FileOutputStream(f).use { inp.copyTo(it) } }
            progress(i + 1, n, "نسخ ${i + 1}/$n")
        }
    }
}

/** أندرويد 11-12: اختيار المجلد عبر SAF */
class SafApplier(private val ctx: Context, private val tree: Uri) : Applier {

    private fun child(dir: DocumentFile, name: String): DocumentFile =
        dir.findFile(name) ?: dir.createDirectory(name) ?: throw IOException("تعذر إنشاء المجلد $name")

    override fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit) {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: throw IOException("المجلد غير صالح")
        if (!root.canWrite()) throw IOException("لا يوجد إذن كتابة على المجلد المختار")

        val base = when (root.name) {
            Config.TARGET_SUBDIR -> root
            pkg -> child(root, Config.TARGET_SUBDIR)
            else -> child(child(root, pkg), Config.TARGET_SUBDIR)
        }

        val dirs = HashMap<String, DocumentFile>()
        fun dirFor(parts: List<String>): DocumentFile {
            var cur = base
            var key = ""
            for (p in parts) {
                key = if (key.isEmpty()) p else "$key/$p"
                val parent = cur
                cur = dirs.getOrPut(key) { child(parent, p) }
            }
            return cur
        }

        val n = src.entries.size
        src.entries.forEachIndexed { i, rel ->
            val parts = cleanRel(rel)
            val name = parts.last()
            val dir = dirFor(parts.dropLast(1))
            dir.findFile(name)?.delete()
            val doc = dir.createFile("application/octet-stream", name)
                ?: throw IOException("تعذر إنشاء الملف $rel")
            val out = ctx.contentResolver.openOutputStream(doc.uri, "wt")
                ?: throw IOException("تعذر الكتابة في $rel")
            out.use { o -> src.open(rel).use { it.copyTo(o) } }
            progress(i + 1, n, "نسخ ${i + 1}/$n")
        }
    }
}

/** كل الإصدارات (خصوصاً 13 إلى 15): عبر Shizuku */
class ShizukuApplier(private val ctx: Context) : Applier {
    override fun apply(src: DataSource, pkg: String, progress: (Int, Int, String) -> Unit) {
        val stage = File(ctx.getExternalFilesDir(null) ?: throw IOException("لا يوجد تخزين خارجي"), "stage")
        stage.deleteRecursively()
        stage.mkdirs()

        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, FileService::class.java.name))
            .processNameSuffix("fs")
            .daemon(false)
            .version(1)
        var conn: ServiceConnection? = null
        try {
            // 1) تجهيز الملفات في مجلد مؤقت يقدر shell يقرأه
            val n = src.entries.size
            src.entries.forEachIndexed { i, rel ->
                val f = File(stage, cleanRel(rel).joinToString("/"))
                f.parentFile?.mkdirs()
                src.open(rel).use { inp -> FileOutputStream(f).use { inp.copyTo(it) } }
                progress(i + 1, n, "تجهيز ${i + 1}/$n")
            }

            // 2) النسخ إلى اللانشر بصلاحيات Shizuku
            progress(0, -1, "جاري النسخ إلى اللانشر...")
            val latch = CountDownLatch(1)
            var svc: IFileService? = null
            val c = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                    if (binder != null && binder.pingBinder()) svc = IFileService.Stub.asInterface(binder)
                    latch.countDown()
                }
                override fun onServiceDisconnected(name: ComponentName?) {}
            }
            conn = c
            Shizuku.bindUserService(args, c)
            if (!latch.await(20, TimeUnit.SECONDS)) throw IOException("تعذر الاتصال بخدمة Shizuku")
            val service = svc ?: throw IOException("تعذر الاتصال بخدمة Shizuku")

            val target = File(Environment.getExternalStorageDirectory(),
                "Android/data/$pkg/${Config.TARGET_SUBDIR}").absolutePath
            val err = service.copyTree(stage.absolutePath, target)
            if (err.isNotEmpty()) throw IOException(err)
        } finally {
            try { conn?.let { Shizuku.unbindUserService(args, it, true) } } catch (_: Throwable) {}
            stage.deleteRecursively()
        }
    }
}
