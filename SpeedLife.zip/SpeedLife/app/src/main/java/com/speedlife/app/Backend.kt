package com.speedlife.app

import org.bouncycastle.crypto.digests.WhirlpoolDigest
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.sql.Connection
import java.sql.DriverManager

class ApiError(message: String, val authFailed: Boolean = false) : Exception(message)

/** Talks to MySQL directly. Same actions the old api.php had. */
object Backend {

    private val JOBS = listOf(
        "Pizzaman", "Trucker", "Fisherman", "Bodyguard", "Arms Dealer", "Miner", "Taxi Driver",
        "Drug Dealer", "Lawyer", "Detective", "Garbage Man", "StreetSweeper", "Farmer",
        "Brinks Job", "Package Job", "Electrical Job", "Window Cleaner"
    )

    private fun jobName(id: Int): String = if (id in JOBS.indices) JOBS[id] else "None"

    private fun Any?.int(): Int = when (this) {
        is Number -> this.toInt()
        is String -> this.toIntOrNull() ?: 0
        else -> 0
    }

    private fun Any?.long(): Long = when (this) {
        is Number -> this.toLong()
        is String -> this.toLongOrNull() ?: 0L
        else -> 0L
    }

    private fun Any?.str(): String = this?.toString() ?: ""

    private class Attempt(val label: String, val driver: String, val url: String)

    private val attempts: List<Attempt> by lazy {
        val hp = "${Config.DB_HOST}:${Config.DB_PORT}/${Config.DB_NAME}"
        val my = "connectTimeout=20000&socketTimeout=30000&characterEncoding=utf8&tinyInt1isBit=false&zeroDateTimeBehavior=convertToNull"
        // MariaDB driver removed: it needs java.sql.DriverAction, which does not exist on Android.
        listOf(
            Attempt("mysql", "com.mysql.jdbc.Driver", "jdbc:mysql://$hp?useSSL=false&allowPublicKeyRetrieval=true&$my"),
            Attempt("mysql-ssl", "com.mysql.jdbc.Driver", "jdbc:mysql://$hp?useSSL=true&requireSSL=false&verifyServerCertificate=false&enabledTLSProtocols=TLSv1.2&$my")
        )
    }

    // index of the attempt that worked last time (tried first next time)
    @Volatile
    private var lastGood = 0

    // Quick TCP check of host:port. Returns null if the port answers, otherwise a clear reason.
    // This is what tells us in 5 seconds that the server is unreachable (instead of 4 long JDBC failures).
    private fun probeTcp(): String? {
        val hp = "${Config.DB_HOST}:${Config.DB_PORT}"
        return try {
            Socket().use { it.connect(InetSocketAddress(Config.DB_HOST, Config.DB_PORT), 5000) }
            null
        } catch (e: SocketTimeoutException) {
            "No answer from $hp (timeout). The port is blocked by a firewall, or remote access to the database is turned off in the hosting panel."
        } catch (e: ConnectException) {
            "Connection refused by $hp. The MySQL port is closed, or the database only accepts local connections."
        } catch (e: UnknownHostException) {
            "Unknown host ${Config.DB_HOST}. Check DB_HOST in Config.kt."
        } catch (e: Exception) {
            "Cannot reach $hp (${e.message ?: e.javaClass.simpleName}). Check the phone's internet connection."
        }
    }

    // Turns long JDBC messages into one readable line.
    private fun friendly(msg: String): String = when {
        msg.contains("Access denied", true) ->
            "The server answered, but refused the database user/password. Check DB_USER / DB_PASS and that this user is allowed from any host (%)."
        msg.contains("Unknown database", true) ->
            "The server answered, but the database '${Config.DB_NAME}' does not exist. Check DB_NAME."
        else -> msg
    }

    /** Used by the green/red dot: (true, null) when a real database session can be opened. */
    fun ping(): Pair<Boolean, String?> {
        probeTcp()?.let { return false to it }
        return try {
            val ok = connect().use { it.isValid(4) }
            if (ok) true to null else false to "Connected, but the database did not answer."
        } catch (e: Throwable) {
            false to friendly(e.message ?: e.javaClass.simpleName)
        }
    }

    // Last line of the root cause (the JDBC top message is often just "Communications link failure").
    private fun rootCause(e: Throwable): String {
        var t: Throwable = e
        var n = 0
        while (t.cause != null && t.cause !== t && n++ < 8) t = t.cause!!
        val top = (e.message ?: e.javaClass.simpleName).lineSequence().first().take(70)
        val root = "${t.javaClass.simpleName}: ${(t.message ?: "").lineSequence().first().take(90)}"
        return if (t === e) top else "$top -> $root"
    }

    // Tries several drivers / SSL modes until one connects.
    // Uses the driver object directly (not DriverManager) so one broken driver cannot hide another.
    private fun connect(): Connection {
        probeTcp()?.let { throw RuntimeException(it) }
        val errors = ArrayList<String>()
        val order = (listOf(lastGood) + attempts.indices.filter { it != lastGood })
        val props = java.util.Properties().apply {
            setProperty("user", Config.DB_USER)
            setProperty("password", Config.DB_PASS)
        }
        for (idx in order) {
            val a = attempts[idx]
            try {
                val drv = Class.forName(a.driver).getDeclaredConstructor().newInstance() as java.sql.Driver
                val c = drv.connect(a.url, props)
                    ?: throw RuntimeException("driver rejected the URL")
                lastGood = idx
                return c
            } catch (e: Throwable) {
                errors.add("[${a.label}] ${rootCause(e)}")
            }
        }
        throw RuntimeException(friendly(errors.joinToString("\n")))
    }

    // Same Whirlpool (uppercase hex) the gamemode's WP_Hash produces
    fun whirlpool(text: String): String {
        val d = WhirlpoolDigest()
        val b = text.toByteArray(Charsets.ISO_8859_1)
        d.update(b, 0, b.size)
        val out = ByteArray(d.digestSize)
        d.doFinal(out, 0)
        return out.joinToString("") { "%02X".format(it.toInt() and 0xFF) }
    }

    private fun rows(c: Connection, sql: String, vararg params: Any?): List<Map<String, Any?>> {
        return c.prepareStatement(sql).use { st ->
            params.forEachIndexed { i, p -> st.setObject(i + 1, p) }
            st.executeQuery().use { rs ->
                val md = rs.metaData
                val list = ArrayList<Map<String, Any?>>()
                while (rs.next()) {
                    val m = HashMap<String, Any?>()
                    for (i in 1..md.columnCount) m[md.getColumnLabel(i)] = rs.getString(i)
                    list.add(m)
                }
                list
            }
        }
    }

    private fun exec(c: Connection, sql: String, vararg params: Any?): Int {
        return c.prepareStatement(sql).use { st ->
            params.forEachIndexed { i, p -> st.setObject(i + 1, p) }
            st.executeUpdate()
        }
    }

    private fun oneValue(c: Connection, sql: String, vararg params: Any?): String {
        val r = rows(c, sql, *params).firstOrNull() ?: return ""
        return r.values.firstOrNull().str()
    }

    private fun ok(): JSONObject = JSONObject().put("ok", true)

    fun handle(action: String, token: String?, input: JSONObject): JSONObject {
        return try {
            connect().use { c -> dispatch(c, action, token, input) }
        } catch (e: ApiError) {
            JSONObject()
                .put("ok", false)
                .put("error", e.message ?: "Error")
                .put("auth_failed", e.authFailed)
        }
    }

    private fun dispatch(c: Connection, action: String, token: String?, input: JSONObject): JSONObject {
        return when (action) {
            "login" -> login(c, input)
            "register" -> register(c, input)
            "me" -> {
                val u = auth(c, token)
                ok().put("profile", profile(c, u["uid"].int()))
            }
            "announce_list" -> {
                auth(c, token)
                announceList(c)
            }
            "announce_create" -> announceCreate(c, token, input)
            "shop_list" -> {
                auth(c, token)
                shopList(c)
            }
            "shop_create" -> shopCreate(c, token, input)
            "shop_buy" -> shopBuy(c, token, input)
            else -> throw ApiError("Unknown action.")
        }
    }

    private fun ensureSchema(c: Connection) {
        val statements = listOf(
            """CREATE TABLE IF NOT EXISTS app_announcements (
                id INT AUTO_INCREMENT PRIMARY KEY,
                author VARCHAR(24) NOT NULL,
                image_url VARCHAR(512) NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            """CREATE TABLE IF NOT EXISTS app_shop_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                model_id SMALLINT NOT NULL,
                price INT NOT NULL,
                quantity INT NOT NULL,
                created_by VARCHAR(24) NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            """CREATE TABLE IF NOT EXISTS app_orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                item_id INT NOT NULL,
                uid INT NOT NULL,
                username VARCHAR(24) NOT NULL,
                model_id SMALLINT NOT NULL,
                price INT NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
        )
        for (s in statements) {
            try {
                exec(c, s)
            } catch (e: Exception) {
                // no CREATE permission or already exists: ignore
            }
        }
    }

    private fun login(c: Connection, input: JSONObject): JSONObject {
        ensureSchema(c)
        val username = input.optString("username").trim()
        val password = input.optString("password")
        if (username.isEmpty() || password.isEmpty() || username.length > 24) {
            throw ApiError("Wrong username or password.")
        }
        val u = rows(c, "SELECT uid, username, password FROM users WHERE username = ? LIMIT 1", username).firstOrNull()
        val stored = u?.get("password").str().uppercase()
        if (u == null || stored.isEmpty() || stored != whirlpool(password)) {
            throw ApiError("Wrong username or password.")
        }
        val uid = u["uid"].int()
        return ok().put("token", "$uid|$stored").put("profile", profile(c, uid))
    }

    private fun register(c: Connection, input: JSONObject): JSONObject {
        ensureSchema(c)
        val username = input.optString("username").trim()
        val password = input.optString("password")
        val age = input.optInt("age")
        // same rule as the gamemode's IsValidName(): 3-24 chars, letters/digits and _ . [ ] ( ) = @
        if (username.length < 3 || username.length > 24 || !Regex("^[A-Za-z0-9_.\\[\\]()=@]+$").matches(username)) {
            throw ApiError("Account name must be 3-24 characters: letters, numbers and _ . [ ] ( ) = @ only.")
        }
        if (password.length < 4 || password.length > 32) throw ApiError("Password must be 4 to 32 characters.")
        if (age < 13 || age > 99) throw ApiError("Age must be between 13 and 99.")
        if (rows(c, "SELECT uid FROM users WHERE username = ? LIMIT 1", username).isNotEmpty()) {
            throw ApiError("This account name is already taken.")
        }
        // Same columns the gamemode fills when a player registers in game (+ age).
        // 'setup' stays at its default so the game runs its normal first-login steps.
        exec(
            c,
            "INSERT INTO users (username, password, regdate, lastlogin, ip, age) VALUES (?, ?, NOW(), NOW(), '0.0.0.0', ?)",
            username, whirlpool(password), age
        )
        return login(c, input)
    }

    private fun auth(c: Connection, token: String?): Map<String, Any?> {
        val t = token ?: throw ApiError("Session expired. Please log in again.", true)
        val i = t.indexOf('|')
        val uid = if (i > 0) t.substring(0, i).toIntOrNull() else null
        if (uid == null) throw ApiError("Session expired. Please log in again.", true)
        val r = rows(c, "SELECT uid, username, password, cash, adminlevel FROM users WHERE uid = ?", uid).firstOrNull()
        if (r == null || r["password"].str().uppercase() != t.substring(i + 1)) {
            throw ApiError("Session expired. Please log in again.", true)
        }
        return r
    }

    private fun isAdmin(u: Map<String, Any?>): Boolean = u["adminlevel"].int() >= Config.ADMIN_MIN_LEVEL

    private fun profile(c: Connection, uid: Int): JSONObject {
        val r = rows(
            c,
            "SELECT uid, username, cash, bank, level, hours, adminlevel, job, secondjob, faction, " +
                "factionrank, gang, gangrank, phone, regdate, lastlogin FROM users WHERE uid = ?",
            uid
        ).firstOrNull() ?: throw ApiError("Account not found.", true)

        var faction = "None"
        var factionRank = ""
        if (r["faction"].int() >= 0) {
            faction = oneValue(c, "SELECT name FROM factions WHERE id = ? LIMIT 1", r["faction"].int()).ifEmpty { "Unknown" }
            factionRank = oneValue(
                c, "SELECT name FROM factionranks WHERE id = ? AND `rank` = ? LIMIT 1",
                r["faction"].int(), r["factionrank"].int()
            )
        }
        var gang = "None"
        var gangRank = ""
        if (r["gang"].int() >= 0) {
            gang = oneValue(c, "SELECT name FROM gangs WHERE id = ? LIMIT 1", r["gang"].int()).ifEmpty { "Unknown" }
            gangRank = oneValue(
                c, "SELECT name FROM gangranks WHERE id = ? AND `rank` = ? LIMIT 1",
                r["gang"].int(), r["gangrank"].int()
            )
        }
        val vehicles = oneValue(c, "SELECT COUNT(*) FROM vehicles WHERE ownerid = ?", uid).toIntOrNull() ?: 0

        return JSONObject()
            .put("uid", r["uid"].int())
            .put("username", r["username"].str())
            .put("cash", r["cash"].long())
            .put("bank", r["bank"].long())
            .put("level", r["level"].int())
            .put("hours", r["hours"].int())
            .put("is_admin", r["adminlevel"].int() >= Config.ADMIN_MIN_LEVEL)
            .put("admin_level", r["adminlevel"].int())
            .put("faction", faction)
            .put("faction_rank", factionRank)
            .put("gang", gang)
            .put("gang_rank", gangRank)
            .put("job", jobName(r["job"].int()))
            .put("second_job", jobName(r["secondjob"].int()))
            .put("phone", r["phone"].int())
            .put("vehicles", vehicles)
            .put("registered", r["regdate"].str())
            .put("last_login", r["lastlogin"].str())
    }

    private fun announceList(c: Connection): JSONObject {
        val arr = JSONArray()
        for (r in rows(c, "SELECT id, author, image_url, message, created_at FROM app_announcements ORDER BY id DESC LIMIT 50")) {
            arr.put(
                JSONObject()
                    .put("id", r["id"].int())
                    .put("author", r["author"].str())
                    .put("image_url", r["image_url"].str())
                    .put("message", r["message"].str())
                    .put("created_at", r["created_at"].str())
            )
        }
        return ok().put("items", arr)
    }

    private fun announceCreate(c: Connection, token: String?, input: JSONObject): JSONObject {
        val u = auth(c, token)
        if (!isAdmin(u)) throw ApiError("Only admins can post announcements.")
        val url = input.optString("image_url").trim()
        val msg = input.optString("message").trim()
        if (!Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(url) || url.length > 500) {
            throw ApiError("The image link must start with http:// or https://")
        }
        if (msg.isEmpty() || msg.length > 1000) throw ApiError("The message must be between 1 and 1000 characters.")
        exec(c, "INSERT INTO app_announcements (author, image_url, message) VALUES (?, ?, ?)", u["username"].str(), url, msg)
        return ok()
    }

    private fun shopList(c: Connection): JSONObject {
        val arr = JSONArray()
        for (r in rows(c, "SELECT id, model_id, price, quantity FROM app_shop_items WHERE quantity > 0 ORDER BY id DESC")) {
            arr.put(
                JSONObject()
                    .put("id", r["id"].int())
                    .put("model_id", r["model_id"].int())
                    .put("price", r["price"].long())
                    .put("quantity", r["quantity"].int())
            )
        }
        return ok().put("items", arr)
    }

    private fun shopCreate(c: Connection, token: String?, input: JSONObject): JSONObject {
        val u = auth(c, token)
        if (!isAdmin(u)) throw ApiError("Only admins can add cars to the shop.")
        val model = input.optInt("model_id")
        val price = input.optLong("price")
        val qty = input.optInt("quantity")
        if (model < 400 || model > 611) throw ApiError("Car ID must be between 400 and 611.")
        if (price < 1 || price > 2000000000L) throw ApiError("Invalid price.")
        if (qty < 1 || qty > 9999) throw ApiError("Quantity must be between 1 and 9999.")
        exec(c, "INSERT INTO app_shop_items (model_id, price, quantity, created_by) VALUES (?, ?, ?, ?)", model, price, qty, u["username"].str())
        return ok()
    }

    private fun shopBuy(c: Connection, token: String?, input: JSONObject): JSONObject {
        val u = auth(c, token)
        val itemId = input.optInt("item_id")

        if (Config.REQUIRE_OFFLINE_TO_BUY) {
            val online = sampOnlineNames()
                ?: throw ApiError("Cannot check the game server right now. Try again later.")
            val me = u["username"].str()
            if (online.any { it.equals(me, ignoreCase = true) }) {
                throw ApiError("You are connected in the game. Leave the game first, then buy.")
            }
        }

        c.autoCommit = false
        try {
            val item = rows(c, "SELECT id, model_id, price, quantity FROM app_shop_items WHERE id = ? FOR UPDATE", itemId).firstOrNull()
            if (item == null || item["quantity"].int() < 1) throw ApiError("Sorry, this car is sold out.")
            val buyer = rows(c, "SELECT uid, username, cash FROM users WHERE uid = ? FOR UPDATE", u["uid"].int()).firstOrNull()
                ?: throw ApiError("Account not found.", true)
            val price = item["price"].long()
            if (buyer["cash"].long() < price) throw ApiError("Not enough cash.")

            if (exec(c, "UPDATE users SET cash = cash - ? WHERE uid = ? AND cash >= ?", price, buyer["uid"].int(), price) != 1) {
                throw ApiError("Not enough cash.")
            }
            if (exec(c, "UPDATE app_shop_items SET quantity = quantity - 1 WHERE id = ? AND quantity > 0", item["id"].int()) != 1) {
                throw ApiError("Sorry, this car is sold out.")
            }
            exec(
                c,
                "INSERT INTO vehicles (ownerid, owner, modelid, price, pos_x, pos_y, pos_z, pos_a) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                buyer["uid"].int(), buyer["username"].str(), item["model_id"].int(), price,
                Config.CAR_SPAWN_X, Config.CAR_SPAWN_Y, Config.CAR_SPAWN_Z, Config.CAR_SPAWN_A
            )
            exec(
                c,
                "INSERT INTO app_orders (item_id, uid, username, model_id, price) VALUES (?, ?, ?, ?, ?)",
                item["id"].int(), buyer["uid"].int(), buyer["username"].str(), item["model_id"].int(), price
            )
            c.commit()
        } catch (e: Exception) {
            try {
                c.rollback()
            } catch (ignored: Exception) {
            }
            throw e
        } finally {
            try {
                c.autoCommit = true
            } catch (ignored: Exception) {
            }
        }
        return ok().put("message", "Purchase complete! Your car is in your account - use /garage in the game.")
    }

    // Asks the SA-MP server who is online (UDP query). Returns null if it cannot be reached.
    private fun sampOnlineNames(): List<String>? {
        return try {
            val addr = InetAddress.getByName(Config.SAMP_HOST)
            val ip = addr.address
            if (ip.size != 4) return null
            val port = Config.SAMP_PORT
            val packet = ByteArray(11)
            "SAMP".toByteArray(Charsets.US_ASCII).copyInto(packet, 0)
            ip.copyInto(packet, 4)
            packet[8] = (port and 0xFF).toByte()
            packet[9] = ((port shr 8) and 0xFF).toByte()
            packet[10] = 'c'.code.toByte()

            val socket = DatagramSocket()
            try {
                socket.soTimeout = 3000
                socket.send(DatagramPacket(packet, packet.size, addr, port))
                val buf = ByteArray(8192)
                val resp = DatagramPacket(buf, buf.size)
                socket.receive(resp)
                parsePlayers(buf, resp.length)
            } finally {
                socket.close()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parsePlayers(buf: ByteArray, len: Int): List<String>? {
        if (len < 13 || String(buf, 0, 4, Charsets.US_ASCII) != "SAMP") return null
        val count = (buf[11].toInt() and 0xFF) or ((buf[12].toInt() and 0xFF) shl 8)
        var pos = 13
        val names = ArrayList<String>()
        for (i in 0 until count) {
            if (pos >= len) return null
            val n = buf[pos].toInt() and 0xFF
            pos += 1
            if (pos + n > len) return null
            names.add(String(buf, pos, n, Charsets.ISO_8859_1))
            pos += n + 4 // + score
        }
        return names
    }
}
