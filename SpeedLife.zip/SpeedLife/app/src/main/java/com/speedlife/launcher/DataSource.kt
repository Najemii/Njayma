package com.speedlife.launcher

import net.lingala.zip4j.ZipFile
import java.io.File
import java.io.IOException
import java.io.InputStream

/** مصدر ملفات الداتا (ملف zip محمي بكلمة سر) */
interface DataSource {
    /** مسارات الملفات النسبية، مثل: texdb/gta3/gta3.img */
    val entries: List<String>
    fun open(rel: String): InputStream
    fun close() {}
}

fun cleanRel(rel: String): List<String> {
    val parts = rel.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
    if (parts.any { it == ".." } || parts.isEmpty()) throw SecurityException("Unsafe path: $rel")
    return parts
}

class ZipSource(file: File, password: String) : DataSource {
    private val zf = ZipFile(file, password.toCharArray())

    override val entries: List<String> = zf.fileHeaders
        .filter { !it.isDirectory }
        .map { it.fileName }
        .filter { !it.startsWith("__MACOSX/") && !it.endsWith(".DS_Store") && !it.endsWith("Thumbs.db") }

    override fun open(rel: String): InputStream {
        val header = zf.getFileHeader(rel) ?: throw IOException("Not found: $rel")
        return zf.getInputStream(header)
    }

    override fun close() {
        try { zf.close() } catch (_: Exception) {}
    }
}
