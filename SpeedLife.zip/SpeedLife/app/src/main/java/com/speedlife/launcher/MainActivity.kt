package com.speedlife.launcher

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.DecelerateInterpolator
import android.view.animation.LayoutAnimationController
import android.view.animation.OvershootInterpolator
import android.view.animation.TranslateAnimation
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

private val RED = 0xFFFF1E1E.toInt()
private val RED_DARK = 0xFFB30000.toInt()
private val CARD = 0xFF121212.toInt()
private val STROKE = 0xFF2A2A2A.toInt()
private val MUTED = 0xFF9A9A9A.toInt()
private val ORANGE = 0xFFFF8A3D.toInt()

class MainActivity : AppCompatActivity() {

    private enum class Method { LEGACY, SAF, SHIZUKU }
    private data class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private lateinit var logo: ImageView
    private lateinit var search: EditText
    private lateinit var showAll: CheckBox
    private lateinit var list: ListView
    private lateinit var methodView: TextView
    private lateinit var dataView: TextView
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private val appAdapter = AppAdapter()
    private val breathing = ArrayList<ObjectAnimator>()
    private var allApps = listOf<AppItem>()
    private var pending: AppItem? = null
    private var waiting: AppItem? = null
    private var busy = false
    private val prefs by lazy { getSharedPreferences("speedlife", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- permission / picker results ----------

    private val legacyPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val item = pending
            if (ok && item != null) startApply(item, Method.LEGACY, null)
            else setStatus("Storage permission denied")
        }

    private val safPicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = r.data?.data
            val item = pending
            if (r.resultCode == RESULT_OK && uri != null && item != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                prefs.edit().putString("saf_${item.pkg}", uri.toString()).apply()
                startApply(item, Method.SAF, uri)
            } else setStatus("No folder selected")
        }

    private val zipPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importZip(uri) else waiting = null
        }

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            val item = pending
            if (result == PackageManager.PERMISSION_GRANTED && item != null) startApply(item, Method.SHIZUKU, null)
            else setStatus("Shizuku permission denied")
        }
    }

    // ---------- UI helpers ----------

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun ripple(content: Drawable, radiusDp: Int) =
        RippleDrawable(ColorStateList.valueOf(0x44FF1E1E), content, rounded(Color.WHITE, radiusDp))

    private fun pressAnim(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun styledButton(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        textSize = 15f
        stateListAnimator = null
        val bg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(RED, RED_DARK))
            .apply { cornerRadius = dp(14).toFloat() }
        background = ripple(bg, 14)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        pressAnim(this)
    }

    private fun enter(v: View, delayMs: Long) {
        v.alpha = 0f
        v.translationY = dp(18).toFloat()
        v.animate().alpha(1f).translationY(0f)
            .setStartDelay(delayMs).setDuration(500)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun startBreathing() {
        for (prop in listOf(View.SCALE_X, View.SCALE_Y)) {
            val a = ObjectAnimator.ofFloat(logo, prop, 1f, 1.04f)
            a.duration = 1800
            a.repeatCount = ObjectAnimator.INFINITE
            a.repeatMode = ObjectAnimator.REVERSE
            a.interpolator = AccelerateDecelerateInterpolator()
            a.start()
            breathing.add(a)
        }
    }

    // ---------- UI ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0B0B0C.toInt(), 0xFF0B0B0C.toInt(), 0xFF1F0606.toInt())
            )
            setPadding(dp(16), dp(24), dp(16), dp(12))
        }

        // Logo with entrance + breathing animation
        logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = 0f
            scaleX = 0.8f
            scaleY = 0.8f
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, dp(150)))
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(700).setInterpolator(OvershootInterpolator(1.2f))
            .withEndAction { startBreathing() }.start()

        // Glowing divider
        val line = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0x00FF1E1E, RED, 0x00FF1E1E)
            )
            scaleX = 0f
        }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(2)).apply { topMargin = dp(6); bottomMargin = dp(10) })
        line.animate().scaleX(1f).setStartDelay(450).setDuration(800).start()

        val subtitle = TextView(this).apply {
            text = "Select a launcher to install the data"
            textSize = 14f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(subtitle)
        enter(subtitle, 300)

        // Data file card
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 16, STROKE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        dataView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        methodView = TextView(this).apply {
            textSize = 12f
            setTextColor(ORANGE)
            setPadding(0, dp(2), 0, dp(10))
        }
        val pickBtn = styledButton("Select data file (zip)").apply {
            setOnClickListener { if (!busy) pickZip() }
        }
        card.addView(dataView)
        card.addView(methodView)
        card.addView(pickBtn, LinearLayout.LayoutParams(-1, -2))
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        enter(card, 400)

        search = EditText(this).apply {
            hint = "Search..."
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF777777.toInt())
            isSingleLine = true
            background = rounded(CARD, 12, STROKE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            doAfterTextChanged { applyFilter(false) }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2))
        enter(search, 500)

        showAll = CheckBox(this).apply {
            text = "Show all apps"
            setTextColor(Color.WHITE)
            buttonTintList = ColorStateList.valueOf(RED)
            setOnCheckedChangeListener { _, _ -> applyFilter(true) }
        }
        root.addView(showAll)

        list = ListView(this).apply {
            adapter = appAdapter
            divider = null
            dividerHeight = 0
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnItemClickListener { _, _, pos, _ ->
                if (!busy) onAppChosen(appAdapter.items[pos])
            }
        }
        val anim = AnimationSet(true).apply {
            addAnimation(AlphaAnimation(0f, 1f).apply { duration = 380 })
            addAnimation(TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 0.4f, Animation.RELATIVE_TO_SELF, 0f
            ).apply { duration = 380; interpolator = DecelerateInterpolator() })
        }
        list.layoutAnimation = LayoutAnimationController(anim, 0.15f)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(RED)
            progressBackgroundTintList = ColorStateList.valueOf(STROKE)
            indeterminateTintList = ColorStateList.valueOf(RED)
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(8) })

        status = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(status)

        setContentView(root)
        updateDataLabel()
        if (!dataZip().exists()) setStatus("Tap \"Select data file\" to start")
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        updateMethodLabel()
        updateDataLabel()
    }

    override fun onDestroy() {
        breathing.forEach { it.cancel() }
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    private fun setProgress(done: Int, total: Int) = runOnUiThread {
        if (total <= 0) {
            bar.isIndeterminate = true
        } else {
            bar.isIndeterminate = false
            bar.setProgress(done * 100 / total, true)
        }
    }

    private fun popStatus() {
        status.scaleX = 0.85f
        status.scaleY = 0.85f
        status.animate().scaleX(1f).scaleY(1f).setDuration(350)
            .setInterpolator(OvershootInterpolator(2f)).start()
    }

    // ---------- app list ----------

    private fun loadApps() {
        lifecycleScope.launch(Dispatchers.IO) {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val apps = pm.getInstalledApplications(0)
                .filter { it.packageName != packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .mapNotNull {
                    try {
                        AppItem(pm.getApplicationLabel(it).toString(), it.packageName, pm.getApplicationIcon(it))
                    } catch (e: Throwable) {
                        null
                    }
                }
                .sortedBy { it.label.lowercase() }
            withContext(Dispatchers.Main) {
                allApps = apps
                applyFilter(true)
            }
        }
    }

    private fun applyFilter(animate: Boolean) {
        if (!::search.isInitialized || !::showAll.isInitialized) return
        val q = search.text.toString().trim().lowercase()
        var res = allApps
        if (!showAll.isChecked) {
            res = res.filter { a ->
                Config.NAME_HINTS.any { a.label.contains(it, true) || a.pkg.contains(it, true) }
            }
        }
        if (q.isNotEmpty()) res = res.filter { it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
        appAdapter.items = res
        appAdapter.notifyDataSetChanged()
        if (animate) list.scheduleLayoutAnimation()
        if (res.isEmpty() && !busy) setStatus("No apps found. Try \"Show all apps\"")
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<AppItem> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val app = items[position]
            val wrap = FrameLayout(this@MainActivity).apply { setPadding(0, dp(5), 0, dp(5)) }
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = ripple(rounded(CARD, 14, STROKE), 14)
            }
            card.addView(ImageView(this@MainActivity).apply { setImageDrawable(app.icon) },
                LinearLayout.LayoutParams(dp(44), dp(44)))
            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(8), 0)
            }
            col.addView(TextView(this@MainActivity).apply {
                text = app.label; textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
            col.addView(TextView(this@MainActivity).apply {
                text = app.pkg; textSize = 12f; setTextColor(MUTED); maxLines = 1
            })
            card.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(TextView(this@MainActivity).apply {
                text = "›"; textSize = 26f; setTextColor(RED)
            })
            wrap.addView(card, FrameLayout.LayoutParams(-1, -2))
            return wrap
        }
    }

    // ---------- method selection ----------

    private fun shizukuRunning() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    private fun shizukuGranted() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun updateMethodLabel() {
        methodView.text = when {
            shizukuRunning() && shizukuGranted() -> "Copy method: Shizuku ✅"
            shizukuRunning() -> "Shizuku is running. Permission will be requested when you pick a launcher"
            Build.VERSION.SDK_INT == 29 -> "Copy method: direct access (Android 10)"
            Build.VERSION.SDK_INT in 30..32 -> "Copy method: folder access (or start Shizuku)"
            else -> "Shizuku is required on Android 13 and above"
        }
    }

    private fun onAppChosen(item: AppItem) {
        if (!dataZip().exists()) {
            waiting = item
            setStatus("Select the data file (zip) first")
            pickZip()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setMessage("The data will be merged into:\n${Config.targetRelPath(item.pkg)}\n\nNew files are added, files with the same name are replaced, everything else stays untouched.")
            .setPositiveButton("Install") { _, _ -> prepare(item) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun prepare(item: AppItem) {
        if (busy) return
        pending = item
        if (shizukuRunning()) {
            if (shizukuGranted()) startApply(item, Method.SHIZUKU, null)
            else Shizuku.requestPermission(1001)
            return
        }
        when {
            Build.VERSION.SDK_INT == 29 -> {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                    startApply(item, Method.LEGACY, null)
                else legacyPerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
            Build.VERSION.SDK_INT in 30..32 -> {
                val saved = prefs.getString("saf_${item.pkg}", null)?.let { Uri.parse(it) }
                val ok = saved != null && contentResolver.persistedUriPermissions.any {
                    it.uri == saved && it.isWritePermission
                }
                if (ok) startApply(item, Method.SAF, saved)
                else {
                    setStatus("Pick the folder ${item.pkg} then tap \"Use this folder\"")
                    safPicker.launch(pickerIntent(item.pkg))
                }
            }
            else -> showShizukuHelp()
        }
    }

    private fun pickerIntent(pkg: String) = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
        putExtra(
            DocumentsContract.EXTRA_INITIAL_URI,
            DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Android/data/$pkg")
        )
        addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
    }

    private fun showShizukuHelp() {
        AlertDialog.Builder(this)
            .setTitle("Shizuku required")
            .setMessage("Android 13 and above blocks apps from writing into another app's data folder.\n\n1) Install the Shizuku app.\n2) Start it (Wireless debugging or Root).\n3) Come back here, pick the launcher again and allow the permission.")
            .setPositiveButton("Get Shizuku") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- data zip ----------

    private fun dataZip() = File(getExternalFilesDir(null) ?: filesDir, "data.zip")

    private fun updateDataLabel() {
        val z = dataZip()
        dataView.text = if (z.exists()) "Data file: ✅ ready (${z.length() / 1048576} MB)"
        else "Data file: ❌ not selected"
    }

    private fun pickZip() = zipPicker.launch(arrayOf("*/*"))

    private fun openSource(): DataSource {
        val z = dataZip()
        if (!z.exists()) throw IllegalStateException("Select the data file first")
        return ZipSource(z, Config.DATA_PASSWORD)
    }

    /** Copy the picked file into app storage and verify the password */
    private fun importZip(uri: Uri) {
        if (busy) return
        busy = true
        list.isEnabled = false
        lifecycleScope.launch {
            var ok = false
            try {
                withContext(Dispatchers.IO) { copyAndVerify(uri) }
                setProgress(100, 100)
                setStatus("Data file imported ✅")
                popStatus()
                updateDataLabel()
                ok = true
            } catch (e: Exception) {
                setProgress(0, 100)
                setStatus("Error: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
                list.isEnabled = true
            }
            val w = waiting
            waiting = null
            if (ok && w != null) prepare(w)
        }
    }

    private fun copyAndVerify(uri: Uri) {
        val dest = dataZip()
        val tmp = File(dest.parentFile, "data.zip.tmp")
        tmp.delete()

        var total = -1L
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && !c.isNull(i)) total = c.getLong(i)
            }
        }

        setStatus("Importing file...")
        val input = contentResolver.openInputStream(uri) ?: throw IOException("Could not open the file")
        var done = 0L
        var lastPct = -1
        input.use { inp ->
            FileOutputStream(tmp).use { out ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            setProgress(pct, 100)
                            setStatus("Importing: ${done / 1048576} / ${total / 1048576} MB")
                        }
                    }
                }
            }
        }

        setStatus("Checking file...")
        val src = try {
            ZipSource(tmp, Config.DATA_PASSWORD)
        } catch (e: Exception) {
            tmp.delete()
            throw IOException("Not a valid zip file")
        }
        try {
            if (src.entries.isEmpty()) throw IOException("The zip is empty")
            try {
                src.open(src.entries.first()).use { it.read() }
            } catch (e: Exception) {
                throw IOException("Wrong password or corrupted file")
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            src.close()
        }

        dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("Could not save the file")
    }

    // ---------- apply ----------

    private fun startApply(item: AppItem, method: Method, tree: Uri?) {
        if (busy) return
        busy = true
        list.isEnabled = false
        lifecycleScope.launch {
            try {
                val src = withContext(Dispatchers.IO) { openSource() }
                try {
                    withContext(Dispatchers.IO) {
                        val applier: Applier = when (method) {
                            Method.LEGACY -> LegacyApplier()
                            Method.SAF -> SafApplier(this@MainActivity, tree!!)
                            Method.SHIZUKU -> ShizukuApplier(this@MainActivity)
                        }
                        applier.apply(src, item.pkg) { d, t, text ->
                            setProgress(d, t)
                            setStatus(text)
                        }
                    }
                } finally {
                    src.close()
                }
                setProgress(100, 100)
                setStatus("Done ✅")
                popStatus()
                offerLaunch(item)
            } catch (e: Exception) {
                setProgress(0, 100)
                setStatus("Error: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
                list.isEnabled = true
            }
        }
    }

    private fun offerLaunch(item: AppItem) {
        val launch = packageManager.getLaunchIntentForPackage(item.pkg) ?: return
        AlertDialog.Builder(this)
            .setTitle("Data installed")
            .setMessage("Open ${item.label} now?")
            .setPositiveButton("Open") { _, _ -> startActivity(launch) }
            .setNegativeButton("Not now", null)
            .show()
    }
}
