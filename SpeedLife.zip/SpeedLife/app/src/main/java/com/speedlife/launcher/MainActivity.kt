package com.speedlife.launcher

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private enum class Method { LEGACY, SAF, SHIZUKU }
    private data class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private lateinit var search: EditText
    private lateinit var showAll: CheckBox
    private lateinit var list: ListView
    private lateinit var methodView: TextView
    private lateinit var dataView: TextView
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private val appAdapter = AppAdapter()
    private var allApps = listOf<AppItem>()
    private var pending: AppItem? = null
    private var waiting: AppItem? = null
    private var busy = false
    private val prefs by lazy { getSharedPreferences("speedlife", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- نتائج الصلاحيات ----------

    private val legacyPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val item = pending
            if (ok && item != null) startApply(item, Method.LEGACY, null)
            else setStatus("تم رفض صلاحية التخزين")
        }

    private val safPicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = r.data?.data
            val item = pending
            if (r.resultCode == RESULT_OK && uri != null && item != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                prefs.edit().putString("saf_${item.pkg}", uri.toString()).apply()
                startApply(item, Method.SAF, uri)
            } else setStatus("لم يتم اختيار المجلد")
        }

    private val zipPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importZip(uri) else waiting = null
        }

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            val item = pending
            if (result == PackageManager.PERMISSION_GRANTED && item != null) startApply(item, Method.SHIZUKU, null)
            else setStatus("تم رفض إذن Shizuku")
        }
    }

    // ---------- الواجهة ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { Shizuku.addRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(16), dp(24), dp(16), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "SpeedLife"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "اختر اللانشر الذي تريد تثبيت الداتا عليه"
            textSize = 14f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, dp(4), 0, dp(8))
        })
        methodView = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFFF8A3D.toInt())
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(methodView)

        dataView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
        }
        val pickBtn = Button(this).apply {
            text = "اختيار ملف الداتا (zip)"
            setOnClickListener { if (!busy) pickZip() }
        }
        root.addView(dataView)
        root.addView(pickBtn)

        search = EditText(this).apply {
            hint = "بحث..."
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF777777.toInt())
            isSingleLine = true
            doAfterTextChanged { applyFilter() }
        }
        root.addView(search)

        showAll = CheckBox(this).apply {
            text = "إظهار كل التطبيقات"
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, _ -> applyFilter() }
        }
        root.addView(showAll)

        list = ListView(this).apply {
            adapter = appAdapter
            divider = ColorDrawable(0xFF222222.toInt())
            dividerHeight = 1
            setOnItemClickListener { _, _, pos, _ ->
                if (!busy) onAppChosen(appAdapter.items[pos])
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        status = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(status)

        setContentView(root)
        updateDataLabel()
        if (!dataZip().exists()) setStatus("اضغط (اختيار ملف الداتا) للبدء")
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        updateMethodLabel()
        updateDataLabel()
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    private fun setProgress(done: Int, total: Int) = runOnUiThread {
        if (total <= 0) {
            bar.isIndeterminate = true
        } else {
            bar.isIndeterminate = false
            bar.progress = done * 100 / total
        }
    }

    // ---------- قائمة التطبيقات ----------

    private fun loadApps() {
        lifecycleScope.launch(Dispatchers.IO) {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val apps = pm.getInstalledApplications(0)
                .filter { it.packageName != packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .mapNotNull {
                    try {
                        AppItem(pm.getApplicationLabel(it).toString(), it.packageName, pm.getApplicationIcon(it))
                    } catch (e: Throwable) {
                        null
                    }
                }
                .sortedBy { it.label.lowercase() }
            withContext(Dispatchers.Main) {
                allApps = apps
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        if (!::search.isInitialized) return
        val q = search.text.toString().trim().lowercase()
        var res = allApps
        if (!showAll.isChecked) {
            res = res.filter { a ->
                Config.NAME_HINTS.any { a.label.contains(it, true) || a.pkg.contains(it, true) }
            }
        }
        if (q.isNotEmpty()) res = res.filter { it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
        appAdapter.items = res
        appAdapter.notifyDataSetChanged()
        if (res.isEmpty() && !busy) setStatus("ما في تطبيقات. جرّب تفعيل (إظهار كل التطبيقات)")
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<AppItem> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val app = items[position]
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(10), 0, dp(10))
            }
            row.addView(ImageView(this@MainActivity).apply { setImageDrawable(app.icon) },
                LinearLayout.LayoutParams(dp(44), dp(44)))
            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            col.addView(TextView(this@MainActivity).apply {
                text = app.label; textSize = 16f; setTextColor(Color.WHITE)
            })
            col.addView(TextView(this@MainActivity).apply {
                text = app.pkg; textSize = 12f; setTextColor(0xFF888888.toInt())
            })
            row.addView(col)
            return row
        }
    }

    // ---------- اختيار الطريقة ----------

    private fun shizukuRunning() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    private fun shizukuGranted() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun updateMethodLabel() {
        methodView.text = when {
            shizukuRunning() && shizukuGranted() -> "طريقة النسخ: Shizuku ✅"
            shizukuRunning() -> "Shizuku يعمل، وسيُطلب منك الإذن عند الاختيار"
            Build.VERSION.SDK_INT == 29 -> "طريقة النسخ: مباشرة (أندرويد 10)"
            Build.VERSION.SDK_INT in 30..32 -> "طريقة النسخ: اختيار المجلد (أو شغّل Shizuku)"
            else -> "يلزم تشغيل Shizuku لأندرويد 13 وما فوق"
        }
    }

    private fun onAppChosen(item: AppItem) {
        if (!dataZip().exists()) {
            waiting = item
            setStatus("اختر ملف الداتا (zip) أولاً")
            pickZip()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setMessage("سيتم نسخ ملفات الداتا إلى هذا اللانشر: الملفات الجديدة تُضاف، والموجودة بنفس الاسم تُستبدل، وباقي ملفات اللانشر تبقى كما هي.")
            .setPositiveButton("ابدأ") { _, _ -> prepare(item) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun prepare(item: AppItem) {
        if (busy) return
        pending = item
        if (shizukuRunning()) {
            if (shizukuGranted()) startApply(item, Method.SHIZUKU, null)
            else Shizuku.requestPermission(1001)
            return
        }
        when {
            Build.VERSION.SDK_INT == 29 -> {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                    startApply(item, Method.LEGACY, null)
                else legacyPerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
            Build.VERSION.SDK_INT in 30..32 -> {
                val saved = prefs.getString("saf_${item.pkg}", null)?.let { Uri.parse(it) }
                val ok = saved != null && contentResolver.persistedUriPermissions.any {
                    it.uri == saved && it.isWritePermission
                }
                if (ok) startApply(item, Method.SAF, saved)
                else {
                    setStatus("اختر مجلد ${item.pkg} ثم اضغط (استخدام هذا المجلد)")
                    safPicker.launch(pickerIntent(item.pkg))
                }
            }
            else -> showShizukuHelp()
        }
    }

    private fun pickerIntent(pkg: String) = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
        putExtra(
            DocumentsContract.EXTRA_INITIAL_URI,
            DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Android/data/$pkg")
        )
        addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
    }

    private fun showShizukuHelp() {
        AlertDialog.Builder(this)
            .setTitle("مطلوب Shizuku")
            .setMessage("أندرويد 13 وما فوق يمنع أي تطبيق من الكتابة في مجلد بيانات تطبيق آخر.\n\n1) ثبّت تطبيق Shizuku.\n2) شغّله (عبر Wireless debugging أو Root).\n3) ارجع هنا واختر اللانشر مرة ثانية ووافق على الإذن.")
            .setPositiveButton("صفحة Shizuku") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    // ---------- التنفيذ ----------

    private fun dataZip() = File(getExternalFilesDir(null) ?: filesDir, "data.zip")

    private fun updateDataLabel() {
        val z = dataZip()
        dataView.text = if (z.exists()) "ملف الداتا: ✅ جاهز (${z.length() / 1048576} MB)"
        else "ملف الداتا: ❌ لم تختره بعد"
    }

    private fun pickZip() = zipPicker.launch(arrayOf("*/*"))

    private fun openSource(): DataSource {
        val z = dataZip()
        if (!z.exists()) throw IllegalStateException("اختر ملف الداتا أولاً")
        return ZipSource(z, Config.DATA_PASSWORD)
    }

    /** نسخ الملف المختار إلى تخزين التطبيق، والتأكد من كلمة السر */
    private fun importZip(uri: Uri) {
        if (busy) return
        busy = true
        list.isEnabled = false
        lifecycleScope.launch {
            var ok = false
            try {
                withContext(Dispatchers.IO) { copyAndVerify(uri) }
                setProgress(100, 100)
                setStatus("تم استيراد ملف الداتا ✅")
                updateDataLabel()
                ok = true
            } catch (e: Exception) {
                setProgress(0, 100)
                setStatus("خطأ: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
                list.isEnabled = true
            }
            val w = waiting
            waiting = null
            if (ok && w != null) prepare(w)
        }
    }

    private fun copyAndVerify(uri: Uri) {
        val dest = dataZip()
        val tmp = File(dest.parentFile, "data.zip.tmp")
        tmp.delete()

        var total = -1L
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && !c.isNull(i)) total = c.getLong(i)
            }
        }

        setStatus("جاري استيراد الملف...")
        val input = contentResolver.openInputStream(uri) ?: throw IOException("تعذر فتح الملف")
        var done = 0L
        var lastPct = -1
        input.use { inp ->
            FileOutputStream(tmp).use { out ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            setProgress(pct, 100)
                            setStatus("استيراد: ${done / 1048576} / ${total / 1048576} MB")
                        }
                    }
                }
            }
        }

        setStatus("جاري فحص الملف...")
        val src = try {
            ZipSource(tmp, Config.DATA_PASSWORD)
        } catch (e: Exception) {
            tmp.delete()
            throw IOException("الملف ليس zip صالحاً")
        }
        try {
            if (src.entries.isEmpty()) throw IOException("ملف الـ zip فاضي")
            try {
                src.open(src.entries.first()).use { it.read() }
            } catch (e: Exception) {
                throw IOException("كلمة السر غير صحيحة أو الملف تالف")
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            src.close()
        }

        dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("تعذر حفظ الملف")
    }

    private fun startApply(item: AppItem, method: Method, tree: Uri?) {
        if (busy) return
        busy = true
        list.isEnabled = false
        lifecycleScope.launch {
            try {
                val src = withContext(Dispatchers.IO) { openSource() }
                try {
                    withContext(Dispatchers.IO) {
                        val applier: Applier = when (method) {
                            Method.LEGACY -> LegacyApplier()
                            Method.SAF -> SafApplier(this@MainActivity, tree!!)
                            Method.SHIZUKU -> ShizukuApplier(this@MainActivity)
                        }
                        applier.apply(src, item.pkg) { d, t, text ->
                            setProgress(d, t)
                            setStatus(text)
                        }
                    }
                } finally {
                    src.close()
                }
                setProgress(100, 100)
                setStatus("تم بنجاح ✅")
                offerLaunch(item)
            } catch (e: Exception) {
                setProgress(0, 100)
                setStatus("خطأ: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
                list.isEnabled = true
            }
        }
    }

    private fun offerLaunch(item: AppItem) {
        val launch = packageManager.getLaunchIntentForPackage(item.pkg) ?: return
        AlertDialog.Builder(this)
            .setTitle("تم تثبيت الداتا")
            .setMessage("هل تريد فتح ${item.label} الآن؟")
            .setPositiveButton("فتح") { _, _ -> startActivity(launch) }
            .setNegativeButton("لا", null)
            .show()
    }
}
