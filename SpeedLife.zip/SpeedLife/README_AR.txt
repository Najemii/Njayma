SpeedLife - data installer for launchers

== Data zip ==
SpeedLife.zip (password 166), the zip ROOT must contain directly:
    files/
    mods/
    configs/
(no extra folder on top). The root is merged into:
    Android/data/<launcher package>/
so you get Android/data/<pkg>/files, /mods, /configs.
Merge rule: new files are added, same-name files are replaced, nothing else is deleted.

Change the password in Config.kt (DATA_PASSWORD), the target in Config.kt (TARGET_SUBDIR).

== Player ==
1) Open SpeedLife, tap "Select data file (zip)" and pick SpeedLife.zip
2) Tap the launcher in the list, then Install.
Android 13-15 needs Shizuku running.

== Build ==
Upload to GitHub, then Actions > Build APK > Run workflow.
